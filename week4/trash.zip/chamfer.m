function chamfer(maskFiles,template_edge)
% B -> maskFiles
% T -> templatge_edge

    for i = 1:length(maskFiles)
        toSplit = strsplit(maskFiles(i).name,{'mask.','.png'});
        mask = imread(strjoin([dirname, '/mask/mask.', toSplit(2), '.png'],''));
        im = imread(strjoin([dirname,'/', toSplit(2),'.jpg'],''));
        im = rgb2gray(im);
        ed = edge(im,'Canny'); % Mask contour from the mask
        D = bwdist(ed,'Euclidean'); % distance transform
    end
end