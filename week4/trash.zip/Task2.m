

dirname = 'train';
maskFiles = dir(fullfile([dirname '/mask/'],'*.png'));
chamfer();